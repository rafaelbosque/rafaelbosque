RAFAEL A. BOSQUE — E-PORTFOLIO V3

This is the self-contained version of the portfolio.
All four images are embedded directly inside index.html:
- Professional profile picture
- Journalism & Writing
- Video & Multimedia
- Agroforestry

You only need index.html to open the website. No assets folder is required.

HOW TO OPEN:
1. Download/extract the ZIP.
2. Double-click index.html.
3. The website should open in your browser with all pictures included.

To edit the website, you can send the index.html back to ChatGPT and describe what you want changed.
